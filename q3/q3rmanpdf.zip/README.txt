***********************************************************	
*							  * 
*     README                                              *                
*     For Q3Radiant Editor Manual                         * 
*     By Paul Jaquays                                     * 
*     Copyright 2000, id Software, inc.                   * 
*     Revision 1.01                                       * 
*                                                         * 
*********************************************************** 

February 17, 2000
This README accompanies the Adobe Acrobat formatted version
of the Q3Radiant editor manual. 

This .pdf file was created by Lucas P. Perry.

He can be reached care of: perry@gamespy.com

February 16, 2000

This manual is based on version 192 of Q3Radiant. This puts it several 
revisions ahead of editor versions of currently available outside id's 
offices. Some of the features documented in the manual are not yet 
active, and others will change to work as described herein. In the mean 
time, you can familiarize yourself with those features and learn of a 
host of undiscovered new ones that have been in there forever (I 
certainly did, and I've been using versions of it for nearly three 
years now).

It is very likely that version 192 of Q3Radiant will be the last major 
revision of features and functionality to the Quake 3 flavor of the 
editor (at least for the foreseeable future). If bugs are discovered, 
those will, as a matter of course, be fixed. But Robert Duffy, id's 
(now) in-house tools programmer will be moving on to making tools for 
our next project. It is possible that his work may be retroactively 
added to Q3Radiant, but if that occurs, it may be a ways down the road 
yet.

Two versions of this manual have been created and archived separately. 
One is a PC format MSWord 97 document. The other is a converted html 
version of the Word document with supporting files.  The html version 
should (repeat should) work with most web browsers (although you may 
have substantially better performance on Internet Explorer than on 
Netscape).

Anyone wishing to convert the manual into a more robust, or more 
accessible on-line document may do so. However, we (id) request that no 
changes be made to the content of the document without id's approval 
and that id be allowed to review and approve the material before it is 
made available for general viewing.

As author and a mapmaker myself, I have tried, as much as humanly 
possible, to make this manual accurate and complete. Nonetheless, 
chances are still very good there are errors and things that I've left 
out. If, after version 192 is released, you discover substantive 
content errors in the document (other than typos), please bring them to 
my attention at: paulj@idsoftware.com. Include the word "Q3R" in the 
subject.

Much of the material in the manual has been adapted with permission 
from publications and postings by other authors. Where possible, 
adapted material has been noted. Many have contributed, but four 
contributors stand out. 

EutecTic developed the final versions of the command key shortcuts 
chart and the entity lists, which became the basis for the sections in 
this manual. We have adapted his Definition file as THE definition for 
the editor. He has also edited the Quake III Arena Shader scripts and 
provided both the missing editor-image textures and those that appear 
only in the Museum and 3Wave CTF maps. The revised shaders and the 
textures will be available (soon) as separate downloads.

Mr. Elusive, who developed his Gladiator bot into the prototype for the 
Quake III Arena bots, contributed his bot bspc document. The changes 
here are mostly for clarity of language (I hope).

Martin Ka'ai Cluney of Raster Graphics did a lot of t-junction fixing 
for id's Q3A maps (thanks Ka'ai!) and contributed his special knowledge 
to manual.

And of course, special thanks go to Robert Duffy, who turned our 
sparely functional Qe4 editor (for Quake 2) into what eventually became 
Q3Radiant. 


Paul Jaquays
Designer
id Software, Inc.

